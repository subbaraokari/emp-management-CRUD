package org.cts.service;

import java.util.List;

import org.cts.dao.EmpDao;
import org.cts.entities.Emp;
import org.springframework.stereotype.Service;

@Service
public class EmpServiceImpl implements EmpService {
	private EmpDao empDao;
	public EmpServiceImpl(EmpDao empDao) {
		super();
		this.empDao = empDao;
	}
	@Override
	public List<Emp> getEmployees() {
		return empDao.getAll();
	}
	@Override
	public Emp getEmployee(int eno) {
		return empDao.get(eno);
	}
	@Override
	public boolean deleteEmployee(int eno) {
		return empDao.delete(eno);
	}
}
