package org.cts.service;

import java.util.List;

import org.cts.entities.Emp;

public interface EmpService {
	List<Emp> getEmployees();
	Emp getEmployee(int eno);
	boolean deleteEmployee(int eno);

}
