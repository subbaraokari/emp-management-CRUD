package org.cts.controllers;

import java.util.List;

import org.cts.entities.Emp;
import org.cts.service.EmpService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {
	private EmpService empService;
		
	public HomeController(EmpService empService) {
		super();
		this.empService = empService;
	}

	@GetMapping("/")
	public ModelAndView showHome() {
		List<Emp> employees=empService.getEmployees();
		ModelAndView mv=new ModelAndView("home");
		mv.addObject("emps",employees);
		return mv;
	}
	@GetMapping("/delete")
	public String delete(@RequestParam("id") int eno) {
		boolean isDeleted=empService.deleteEmployee(eno);
		String viewName="";
		if(isDeleted) {
			viewName="redirect:/";
		}
		return viewName;
	}
}
